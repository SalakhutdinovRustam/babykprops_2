<?php
/**
 * @author OnTheGo Systems
 */
interface IWPML_Backend_Action extends IWPML_Action {
}
