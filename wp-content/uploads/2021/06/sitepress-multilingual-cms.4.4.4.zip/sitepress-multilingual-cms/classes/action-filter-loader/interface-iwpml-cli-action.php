<?php
/**
 * @author OnTheGo Systems
 */
interface IWPML_CLI_Action extends IWPML_Action {
}
